declare module "*"{
  const value: any;
  export default value;
}
